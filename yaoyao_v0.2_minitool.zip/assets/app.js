/**
 * 药药 v0.2
 * 运行环境：小红书小工具（离线 H5 / 容器沙箱）
 * 兼容基线：ES2017 / Chrome 61，不使用 ?. ?? 对象展开等新语法
 */
(function () {
  'use strict';

  var STORAGE_KEY = 'yaoyao_state_v2';
  var MIN_FS_VERSION = 9490;

  var state = createDefaultState();
  var platform = {
    active: false,
    mt: null,
    buildVersion: 0,
    userDataPath: '',
    storage: false,
    fs: false
  };
  var view = {
    page: 'home',
    month: new Date(),
    photoData: '',
    existingPhoto: '',
    status: '',
    pillIndex: 0
  };

  /* ---------------------------------------------------------- 基础工具 */

  function createDefaultState() {
    return {
      version: 2,
      medication: null,
      records: {},
      blister: { size: 21, taken: [] },
      settings: { reminderOn: true }
    };
  }

  function $(id) {
    return document.getElementById(id);
  }

  function pad2(n) {
    return n < 10 ? '0' + n : '' + n;
  }

  function dateKey(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  }

  function parseKey(key) {
    var parts = key.split('-');
    return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  }

  function todayKey() {
    return dateKey(new Date());
  }

  function esc(value) {
    return String(value === null || value === undefined ? '' : value).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  var toastTimer = null;
  function toast(message) {
    var el = $('toast');
    if (!el) return;
    el.textContent = message;
    el.className = 'toast is-show';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      el.className = 'toast';
    }, 2400);
  }

  function statusText(status) {
    if (status === 'taken') return '已确认服用';
    if (status === 'not_taken') return '尚未服用';
    if (status === 'uncertain') return '状态不确定';
    return '尚未记录';
  }

  function statusClass(status) {
    if (status === 'taken') return 'ok';
    if (status === 'not_taken') return 'warn';
    if (status === 'uncertain') return 'warn';
    return '';
  }

  function timeText(iso) {
    if (!iso) return '';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    return pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }

  /* ---------------------------------------------------------- 平台适配 */

  function detectPlatform() {
    var mt = window.xhs && window.xhs.miniTool;
    if (!mt) return;
    platform.mt = mt;
    platform.active = true;
    platform.storage = typeof mt.setStorage === 'function' && typeof mt.getStorage === 'function';
  }

  function toVersion(value) {
    if (value === null || value === undefined || value === '') return 0;
    var text = String(value);
    if (text.indexOf('.') > -1) {
      var parts = text.split('.');
      return (parseInt(parts[0], 10) || 0) * 1000 +
        (parseInt(parts[1], 10) || 0) * 10 +
        (parseInt(parts[2], 10) || 0);
    }
    return parseInt(text, 10) || 0;
  }

  function initPlatform() {
    var mt = platform.mt;
    if (!mt) return Promise.resolve();

    var task;
    if (typeof mt.getLaunchOptions === 'function') {
      task = mt.getLaunchOptions().then(null, function () { return null; });
    } else {
      task = Promise.resolve(null);
    }

    return task.then(function (options) {
      var env = options && options.miniToolEnv ? options.miniToolEnv : {};
      platform.userDataPath = env.userDataPath || '';
      platform.buildVersion = toVersion(env.buildVersion || (options && options.clientVersion));

      var hasFileApi = typeof mt.mkdir === 'function' &&
        typeof mt.writeFile === 'function' &&
        typeof mt.readFile === 'function';

      platform.fs = hasFileApi &&
        !!platform.userDataPath &&
        (platform.buildVersion === 0 || platform.buildVersion >= MIN_FS_VERSION);
    });
  }

  function loadState() {
    if (!platform.active || !platform.storage) return Promise.resolve();
    return platform.mt.getStorage({ key: STORAGE_KEY }).then(function (res) {
      var raw = res && res.data;
      if (!raw) return;
      var parsed = JSON.parse(raw);
      if (!parsed || parsed.version !== 2) return;
      state = normalizeState(parsed);
    }, function () {
      toast('读取本地记录失败，请稍后重试');
    });
  }

  function normalizeState(input) {
    var next = createDefaultState();
    if (input.medication) next.medication = input.medication;
    if (input.records && typeof input.records === 'object') next.records = input.records;
    if (input.blister && typeof input.blister === 'object') {
      next.blister.size = Number(input.blister.size) || 21;
      next.blister.taken = Array.isArray(input.blister.taken) ? input.blister.taken : [];
    }
    if (input.settings && typeof input.settings === 'object') {
      next.settings.reminderOn = input.settings.reminderOn !== false;
    }
    return next;
  }

  function persist() {
    if (!platform.active) {
      toast('预览模式：记录不会保存');
      return Promise.resolve(false);
    }
    if (!platform.storage) {
      toast('当前客户端不支持本地存储，记录无法保存');
      return Promise.resolve(false);
    }
    return platform.mt.setStorage({
      key: STORAGE_KEY,
      data: JSON.stringify(state)
    }).then(function (res) {
      if (res && res.errMsg === 'setStorage:ok') return true;
      toast('保存失败，请重试');
      return false;
    }, function () {
      toast('保存失败，请重试');
      return false;
    });
  }

  function savePhoto(dataUrl) {
    if (!platform.fs) return Promise.resolve('');
    var base64 = dataUrl.indexOf(',') > -1 ? dataUrl.split(',')[1] : dataUrl;
    var dir = platform.userDataPath + '/photos';
    var filePath = dir + '/' + todayKey() + '.jpg';

    return platform.mt.mkdir({ dirPath: dir, recursive: true }).then(null, function () {
      return null;
    }).then(function () {
      return platform.mt.writeFile({ filePath: filePath, data: base64, encoding: 'base64' });
    }).then(function () {
      return filePath;
    }, function () {
      toast('照片保存失败，本条记录将不含照片');
      return '';
    });
  }

  /* ---------------------------------------------------------- 业务数据 */

  function blisterSize() {
    if (state.medication && Number(state.medication.slots)) {
      return Number(state.medication.slots);
    }
    return state.blister.size || 21;
  }

  function takenPills() {
    return state.blister.taken || [];
  }

  function nextPillIndex() {
    var size = blisterSize();
    var taken = takenPills();
    for (var i = 1; i <= size; i++) {
      if (taken.indexOf(i) === -1) return i;
    }
    return size;
  }

  function addPill(index) {
    var num = Number(index);
    if (!num || num < 1 || num > blisterSize()) return;
    if (takenPills().indexOf(num) === -1) {
      state.blister.taken.push(num);
    }
  }

  function isPastReminder() {
    var med = state.medication;
    if (!med || !med.time) return false;
    var parts = String(med.time).split(':');
    if (parts.length < 2) return false;
    var now = new Date();
    return (now.getHours() * 60 + now.getMinutes()) >=
      (Number(parts[0]) * 60 + Number(parts[1]));
  }

  /* ---------------------------------------------------------- 渲染 */

  function renderAll() {
    renderTop();
    renderHome();
    renderCheckin();
    renderCalendar();
    renderProfile();
  }

  function renderTop() {
    var now = new Date();
    var week = ['日', '一', '二', '三', '四', '五', '六'][now.getDay()];
    $('topDate').textContent = (now.getMonth() + 1) + '月' + now.getDate() + '日 周' + week;
  }

  function renderHome() {
    var key = todayKey();
    var record = state.records[key];
    var med = state.medication;
    var card = $('todayCard');
    var statusEl = $('todayStatus');
    var title = $('todayTitle');
    var lead = $('todayLead');
    var button = card.querySelector('[data-action="goto-checkin"]');

    card.className = 'today-card';
    statusEl.textContent = record ? statusText(record.status) : '尚未记录';
    statusEl.className = 'status ' + (record ? statusClass(record.status) : '');

    if (!record) {
      if (med && state.settings.reminderOn && isPastReminder()) {
        card.className = 'today-card is-alert';
        title.textContent = '已经过了你平时的服药时间';
        lead.textContent = '如果还没记录，现在补一条，之后回看会更清楚。';
      } else {
        title.textContent = '今天还没有记录';
        lead.textContent = med ? '拍一张照片，再确认今天的服药情况。' : '先在「我的」里建立药品档案，再来打卡。';
      }
      button.textContent = med ? '拍照打卡' : '建立药品档案';
    } else {
      title.textContent = '今天' + statusText(record.status);
      lead.textContent = record.status === 'taken'
        ? '记录时间是 ' + timeText(record.updatedAt || record.createdAt) + '，可以随时重新记录。'
        : '可以随时回来修改今天的记录。';
      button.textContent = '重新记录';
    }

    renderBlister();
    renderStats();
    renderRecent();
  }

  function renderBlister() {
    var size = blisterSize();
    var taken = takenPills();
    var grid = $('blisterGrid');
    var next = nextPillIndex();
    var html = '';

    for (var i = 1; i <= size; i++) {
      var cls = 'pill';
      if (taken.indexOf(i) > -1) cls += ' is-taken';
      else if (i === next) cls += ' is-next';
      html += '<div class="' + cls + '" data-index="' + i + '"></div>';
    }
    grid.innerHTML = html;

    var count = taken.length;
    var percent = size ? Math.round(count / size * 100) : 0;
    $('blisterProgress').textContent = count + ' / ' + size;
    $('blisterBar').style.width = percent + '%';

    var med = state.medication;
    $('blisterMeta').textContent = med
      ? esc(med.name) + ' · 每板 ' + size + ' 颗'
      : '尚未建立药品档案';
  }

  function renderStats() {
    var keys = Object.keys(state.records);
    var taken = 0;
    var pending = 0;
    keys.forEach(function (key) {
      var status = state.records[key].status;
      if (status === 'taken') taken++;
      else pending++;
    });
    $('statDays').textContent = keys.length;
    $('statTaken').textContent = taken;
    $('statPending').textContent = pending;
  }

  function renderRecent() {
    var list = $('recentList');
    var keys = Object.keys(state.records).sort(function (a, b) {
      return a < b ? 1 : -1;
    }).slice(0, 3);

    if (!keys.length) {
      list.innerHTML = '<div class="empty">还没有记录，今天可以开始。</div>';
      return;
    }

    var html = '';
    keys.forEach(function (key) {
      var record = state.records[key];
      var parts = key.split('-');
      html += '<div class="record">' +
        '<div class="record-date">' + parts[1] + '/' + parts[2] + '</div>' +
        '<div class="record-main">' + esc(statusText(record.status)) +
        '<div class="record-sub">' + esc(timeText(record.updatedAt || record.createdAt)) + ' 记录</div></div>' +
        '<span class="record-dot ' + esc(record.status) + '"></span>' +
        '</div>';
    });
    list.innerHTML = html;
  }

  function renderCheckin() {
    var img = $('photoPreview');
    var empty = $('photoEmpty');
    var source = view.photoData || view.existingPhoto;

    if (source) {
      img.src = source;
      img.hidden = false;
      empty.hidden = true;
    } else {
      img.removeAttribute('src');
      img.hidden = true;
      empty.hidden = false;
    }

    var buttons = document.querySelectorAll('#statusChoice button');
    for (var i = 0; i < buttons.length; i++) {
      var isOn = buttons[i].getAttribute('data-status') === view.status;
      buttons[i].className = isOn ? 'is-on' : '';
    }

    $('pillField').hidden = view.status !== 'taken';

    var size = blisterSize();
    var select = $('pillSelect');
    var html = '';
    for (var j = 1; j <= size; j++) {
      var selected = Number(view.pillIndex) === j ? ' selected' : '';
      html += '<option value="' + j + '"' + selected + '>第 ' + j + ' 颗</option>';
    }
    select.innerHTML = html;
  }

  function renderCalendar() {
    var year = view.month.getFullYear();
    var month = view.month.getMonth();
    var first = new Date(year, month, 1);
    var total = new Date(year, month + 1, 0).getDate();
    var offset = (first.getDay() + 6) % 7;
    var grid = $('calGrid');
    var html = '';
    var weekdays = ['一', '二', '三', '四', '五', '六', '日'];

    $('calTitle').textContent = year + ' 年 ' + (month + 1) + ' 月';

    weekdays.forEach(function (name) {
      html += '<div class="cal-wd">' + name + '</div>';
    });
    for (var b = 0; b < offset; b++) {
      html += '<div class="cal-blank"></div>';
    }

    var today = todayKey();
    for (var day = 1; day <= total; day++) {
      var key = year + '-' + pad2(month + 1) + '-' + pad2(day);
      var record = state.records[key];
      var cls = 'cal-day';
      if (record) {
        if (record.status === 'taken') cls += ' is-taken';
        else if (record.status === 'not_taken') cls += ' is-not-taken';
        else cls += ' is-uncertain';
      }
      if (key === today) cls += ' is-today';
      html += '<button class="' + cls + '" data-action="open-day" data-date="' + key + '">' + day + '</button>';
    }
    grid.innerHTML = html;
  }

  function renderProfile() {
    var med = state.medication;
    $('medName').value = med ? med.name : '';
    $('medSlots').value = String(med ? Number(med.slots) : 21);
    $('medTime').value = med && med.time ? med.time : '21:00';
    $('medStart').value = med && med.startDate ? med.startDate : todayKey();
    $('medNote').value = med && med.note ? med.note : '';

    var sw = $('reminderSwitch');
    if (state.settings.reminderOn) {
      sw.className = 'switch is-on';
      sw.setAttribute('aria-pressed', 'true');
    } else {
      sw.className = 'switch';
      sw.setAttribute('aria-pressed', 'false');
    }
  }

  /* ---------------------------------------------------------- 页面切换 */

  function switchPage(name) {
    view.page = name;
    var pages = document.querySelectorAll('.page');
    for (var i = 0; i < pages.length; i++) {
      pages[i].className = pages[i].getAttribute('data-page') === name ? 'page is-active' : 'page';
    }
    var tabs = document.querySelectorAll('.tab');
    for (var j = 0; j < tabs.length; j++) {
      tabs[j].className = tabs[j].getAttribute('data-nav') === name ? 'tab is-active' : 'tab';
    }
    window.scrollTo(0, 0);
    if (name === 'calendar') renderCalendar();
    if (name === 'profile') renderProfile();
  }

  function openCheckin() {
    var record = state.records[todayKey()];
    view.status = record ? record.status : '';
    view.pillIndex = record && record.pillIndex ? record.pillIndex : nextPillIndex();
    view.photoData = '';
    view.existingPhoto = record && record.photo ? record.photo : '';
    renderCheckin();
    switchPage('checkin');
  }

  /* ---------------------------------------------------------- 记录保存 */

  function saveRecord() {
    if (!view.status) {
      toast('请先选择今天实际的服药情况');
      return;
    }
    if (!view.photoData && !view.existingPhoto) {
      if (!window.confirm('今天还没有照片，仍然保存这条记录吗？')) return;
    }
    commitRecord();
  }

  function commitRecord() {
    var key = todayKey();
    var previous = state.records[key] || {};

    var write = function (photoPath) {
      var now = new Date().toISOString();
      state.records[key] = {
        status: view.status,
        pillIndex: view.status === 'taken' ? Number(view.pillIndex) : 0,
        photo: photoPath || previous.photo || '',
        createdAt: previous.createdAt || now,
        updatedAt: now
      };
      if (view.status === 'taken') addPill(Number(view.pillIndex));

      persist().then(function (ok) {
        renderAll();
        switchPage('home');
        if (ok) toast('今天的记录已保存');
      });
    };

    if (view.photoData) {
      savePhoto(view.photoData).then(write);
    } else {
      write('');
    }
  }

  /* ---------------------------------------------------------- 日历详情 */

  function openDay(key) {
    var record = state.records[key];
    var date = parseKey(key);
    var sheet = $('sheetBody');
    var html = '<h3>' + (date.getMonth() + 1) + ' 月 ' + date.getDate() + ' 日</h3>';

    if (!record) {
      html += '<p class="sheet-sub">这一天没有记录。</p>' +
        '<p class="help">没有记录不代表漏服，也不代表已服用。</p>' +
        '<button class="btn ghost block" data-action="close-sheet">知道了</button>';
    } else {
      html += '<p class="sheet-sub">' + esc(statusText(record.status)) +
        ' · ' + esc(timeText(record.updatedAt || record.createdAt)) + ' 记录</p>';
      if (record.photo) {
        html += '<img src="' + esc(record.photo) + '" alt="当日药板照片">';
      } else {
        html += '<p class="help">这一天没有保存照片。</p>';
      }
      if (record.status === 'taken' && record.pillIndex) {
        html += '<p class="help">标记为第 ' + Number(record.pillIndex) + ' 颗。</p>';
      }
      html += '<button class="btn ghost block" data-action="close-sheet">关闭</button>';
    }

    sheet.innerHTML = html;
    $('sheetMask').hidden = false;
  }

  function closeSheet() {
    $('sheetMask').hidden = true;
    $('sheetBody').innerHTML = '';
  }

  /* ---------------------------------------------------------- 事件 */

  function bindEvents() {
    document.addEventListener('click', onClick);

    $('photoInput').addEventListener('change', function (event) {
      var file = event.target.files && event.target.files[0];
      if (!file) return;
      if (file.type && file.type.indexOf('image/') !== 0) {
        toast('请选择图片文件');
        return;
      }
      compressImage(file, function (dataUrl) {
        if (!dataUrl) {
          toast('图片处理失败，请重试');
          return;
        }
        view.photoData = dataUrl;
        renderCheckin();
      });
      event.target.value = '';
    });

    $('sheetMask').addEventListener('click', function (event) {
      if (event.target === $('sheetMask')) closeSheet();
    });
  }

  function onClick(event) {
    var node = event.target;
    var action = '';

    while (node && node.nodeType === 1) {
      if (node.getAttribute('data-nav')) {
        switchPage(node.getAttribute('data-nav'));
        return;
      }
      if (node.getAttribute('data-action')) {
        action = node.getAttribute('data-action');
        break;
      }
      if (node === document.body) break;
      node = node.parentNode;
    }

    if (!action) return;
    handleAction(action, node);
  }

  function handleAction(action, node) {
    switch (action) {
      case 'goto-checkin':
        if (!state.medication) {
          switchPage('profile');
          toast('先建立药品档案，再开始打卡');
          return;
        }
        openCheckin();
        break;
      case 'goto-calendar':
        switchPage('calendar');
        break;
      case 'pick-photo':
        $('photoInput').click();
        break;
      case 'reset-photo':
        view.photoData = '';
        view.existingPhoto = '';
        renderCheckin();
        break;
      case 'pick-status':
        view.status = node.getAttribute('data-status');
        renderCheckin();
        break;
      case 'save-record':
        saveRecord();
        break;
      case 'prev-month':
        view.month = new Date(view.month.getFullYear(), view.month.getMonth() - 1, 1);
        renderCalendar();
        break;
      case 'next-month':
        view.month = new Date(view.month.getFullYear(), view.month.getMonth() + 1, 1);
        renderCalendar();
        break;
      case 'open-day':
        openDay(node.getAttribute('data-date'));
        break;
      case 'close-sheet':
        closeSheet();
        break;
      case 'save-med':
        saveMedication();
        break;
      case 'toggle-reminder':
        state.settings.reminderOn = !state.settings.reminderOn;
        renderProfile();
        persist();
        break;
      case 'new-blister':
        if (window.confirm('确认换了一板新药？药板上的已取标记会清空。')) {
          state.blister.taken = [];
          persist();
          renderAll();
          toast('已换新板');
        }
        break;
      case 'clear-data':
        confirmClear();
        break;
      default:
        break;
    }
  }

  function saveMedication() {
    var name = $('medName').value.replace(/^\s+|\s+$/g, '');
    var slots = Number($('medSlots').value);
    var time = $('medTime').value || '21:00';
    var startDate = $('medStart').value || todayKey();
    var note = $('medNote').value.replace(/^\s+|\s+$/g, '');

    if (!name) {
      toast('请填写药品名称');
      return;
    }
    if (slots !== 21 && slots !== 28) {
      toast('药位数请选择 21 或 28');
      return;
    }

    state.medication = {
      name: name,
      slots: slots,
      time: time,
      startDate: startDate,
      note: note
    };

    if (state.blister.size !== slots) {
      state.blister.size = slots;
      state.blister.taken = [];
    }

    persist().then(function (ok) {
      renderAll();
      if (ok) toast('药品档案已保存');
    });
  }

  function confirmClear() {
    if (!window.confirm('清除后，本机的药品档案、全部记录和照片都无法恢复。确定继续吗？')) return;

    var done = function () {
      state = createDefaultState();
      view.photoData = '';
      view.existingPhoto = '';
      view.status = '';
      renderAll();
      switchPage('home');
      toast('本地数据已清除');
    };

    if (platform.active && typeof platform.mt.clearStorage === 'function') {
      platform.mt.clearStorage().then(done, function () {
        toast('清除失败，请稍后重试');
      });
    } else {
      done();
    }
  }

  /* ---------------------------------------------------------- 图片压缩 */

  function compressImage(file, callback) {
    var reader = new FileReader();
    reader.onload = function () {
      var img = new Image();
      img.onload = function () {
        var maxSide = 1000;
        var width = img.width;
        var height = img.height;
        var scale = Math.min(1, maxSide / Math.max(width, height));
        var canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(width * scale));
        canvas.height = Math.max(1, Math.round(height * scale));
        var ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        try {
          callback(canvas.toDataURL('image/jpeg', 0.72));
        } catch (err) {
          callback('');
        }
      };
      img.onerror = function () { callback(''); };
      img.src = reader.result;
    };
    reader.onerror = function () { callback(''); };
    reader.readAsDataURL(file);
  }

  /* ---------------------------------------------------------- 启动 */

  function boot() {
    bindEvents();
    detectPlatform();

    if (!platform.active) {
      $('previewBanner').hidden = false;
    }

    initPlatform().then(function () {
      return loadState();
    }).then(function () {
      renderAll();
      switchPage('home');
    }, function () {
      renderAll();
      switchPage('home');
    });
  }

  boot();
})();
